import mysql.connector
from mysql.connector import errorcode

# --- DATABASE CONNECTION ---
# Password has been updated to Arman@12
def connect_to_database():
    try:
        cnx = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Arman@12",  # <-- YOUR PASSWORD IS NOW HERE!
            database="timetable_db"
        )
        print("Connection successful!")
        return cnx
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("ERROR: Something is wrong with your user name or password. Please check the password line in the code.")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("ERROR: Database does not exist. Did you run the SQL commands in Workbench?")
        else:
            print(err)
        return None 

# --- MAIN FUNCTIONS (CRUD Operations) ---

# 1. CREATE A NEW TASK
def add_task(cnx):
    print("\n--- Add a New Task ---")
    task_name = input("What is the task? ")
    day_of_week = input("What day of the week (e.g., Monday)? ")

    cursor = cnx.cursor()
    query = "INSERT INTO tasks (task_name, day_of_week) VALUES (%s, %s)"
    values = (task_name, day_of_week)

    try:
        cursor.execute(query, values)
        cnx.commit() 
        print(f"Success! Added '{task_name}' on {day_of_week}.")
    except mysql.connector.Error as err:
         print(f"Error adding task: {err}")
    finally:
         cursor.close()

# 2. VIEW TASKS FOR A DAY (Your Checklist - READ)
def view_tasks(cnx):
    print("\n--- View Tasks (Your Checklist) ---")
    day_to_see = input("Which day do you want to see? ")

    cursor = cnx.cursor()
    query = "SELECT id, task_name, is_done FROM tasks WHERE day_of_week = %s ORDER BY id ASC"

    try:
        cursor.execute(query, (day_to_see,))
        results = cursor.fetchall()

        if not results:
            print(f"No tasks found for {day_to_see}.")
        else:
            print(f"\n--- Tasks for {day_to_see} ---")
            print("---------------------------------")
            for (task_id, task_name, is_done) in results:
                status = "[X]" if is_done == 1 else "[ ]" 
                print(f"{status} ID: {task_id} - {task_name}")
            print("---------------------------------")
    except mysql.connector.Error as err:
         print(f"Error viewing tasks: {err}")
    finally:
        cursor.close()

# 3. MARK A TASK AS DONE (UPDATE the checklist status)
def mark_task_done(cnx):
    print("\n--- Mark a Task as Done ---")
    try:
        task_id_to_mark = int(input("Enter the ID of the task you completed: "))

        cursor = cnx.cursor()
        query = "UPDATE tasks SET is_done = TRUE WHERE id = %s"

        cursor.execute(query, (task_id_to_mark,))
        cnx.commit() 

        if cursor.rowcount == 0:
            print(f"No task found with ID {task_id_to_mark}.")
        else:
            print(f"Success! Task {task_id_to_mark} marked as done.")
        
    except ValueError:
        print("Invalid input. Please enter a number for the ID.")
    except mysql.connector.Error as err:
         print(f"Error marking task: {err}")
    finally:
        cursor.close()


# 4. UPDATE A TASK'S DAY (UPDATE the day_of_week)
def update_task_day(cnx):
    print("\n--- Update a Task's Day ---")
    try:
        task_id_to_update = int(input("Enter the ID of the task you want to move: "))
        new_day = input("What is the new day for this task? ")

        cursor = cnx.cursor()
        query = "UPDATE tasks SET day_of_week = %s WHERE id = %s"
        
        cursor.execute(query, (new_day, task_id_to_update))
        cnx.commit() 

        if cursor.rowcount == 0:
            print(f"No task found with ID {task_id_to_update}.")
        else:
            print(f"Success! Moved task {task_id_to_update} to {new_day}.")

    except ValueError:
        print("Invalid input. Please enter a number for the ID.")
    except mysql.connector.Error as err:
         print(f"Error updating day: {err}")
    finally:
         cursor.close()

# 5. DELETE A TASK (DELETE)
def delete_task(cnx):
    print("\n--- Delete a Task ---")
    try:
        task_id_to_delete = int(input("Enter the ID of the task you want to delete: "))

        cursor = cnx.cursor()
        query = "DELETE FROM tasks WHERE id = %s"

        cursor.execute(query, (task_id_to_delete,))
        cnx.commit() 

        if cursor.rowcount == 0:
            print(f"No task found with ID {task_id_to_delete}.")
        else:
            print(f"Success! Deleted task {task_id_to_delete}.")
        
    except ValueError:
        print("Invalid input. Please enter a number for the ID.")
    except mysql.connector.Error as err:
         print(f"Error deleting task: {err}")
    finally:
         cursor.close()


# --- THE MAIN MENU ---
def print_menu():
    print("\n=============================")
    print("  My Weekly Timetable Menu")
    print("=============================")
    print("1. View tasks for a day (Checklist)")
    print("2. Add a new task")
    print("3. Mark a task as done")
    print("4. Update a task's day")
    print("5. Delete a task")
    print("6. Exit")
    print("=============================")

# --- THE MAIN PROGRAM LOOP ---
def main():
    db_connection = connect_to_database()

    if db_connection is None:
        print("Exiting program due to database connection failure.")
        return

    while True:
        print_menu()
        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            view_tasks(db_connection)
        elif choice == '2':
            add_task(db_connection)
        elif choice == '3':
            mark_task_done(db_connection)
        elif choice == '4':
            update_task_day(db_connection)
        elif choice == '5':
            delete_task(db_connection)
        elif choice == '6':
            print("Goodbye! Your tasks are saved.")
            break 
        else:
            print("Invalid choice. Please enter a number between 1 and 6.")

    db_connection.close()
    print("Database connection closed.")

if __name__ == "__main__":
    main()